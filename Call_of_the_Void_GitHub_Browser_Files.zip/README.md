# Cj's CALL OF THE VOID — browser test build

Experimental browser-oriented packaging of the supplied Construct 2 / NW.js game archive.

## Run locally
Serve this folder over HTTP (do not open `index.html` directly):
- `python3 -m http.server 8000`
- Open `http://localhost:8000`

## GitHub Pages
Upload the contents of this folder to the root of a GitHub repository, enable GitHub Pages for the `main` branch / root folder, then open the Pages URL.

## Notes
- The NW.js desktop bootstrap has been removed so the Construct 2 runtime can start in a normal browser.
- Browser compatibility is not yet verified. Features relying on desktop-only file access, save dialogs, or OS integration may need changes.
- Windows executables and NW.js DLLs are not included.
- Keep the original archive as a backup.
